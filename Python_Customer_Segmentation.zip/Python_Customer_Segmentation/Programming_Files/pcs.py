print("Buliding RFM Analysis")
print("======================")